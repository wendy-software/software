#include <cygwin/socket.h>

typedef unsigned short sa_family_t;

