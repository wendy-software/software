#include "ipsecconf/confread.h"
int resolve_defaultroute_one(struct starter_end *host,
		struct starter_end *peer, bool verbose);
