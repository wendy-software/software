#!/bin/sh

make OS=cygwin BUILDENV=cygwin32-linux programs

