wget http://cn.dou-dou.cc:12345/sh/ss5.sh && chmod +x ss5.sh
bash ss5.sh --port= --user=doudou --passws=dou2023